number = int(input("Enter the number 1, 2, 3, or 4: "))

if number == 1:
    print("ONE")
if number == 2:
    print("TWO")
if number == 3:
    print("THREE")
if number == 4:
    print("FOUR")