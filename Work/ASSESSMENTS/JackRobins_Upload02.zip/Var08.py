# Contact: jacko8967@gmail.com
# Date Written: 21.02.2021
# Version: 1.0

# initialise values to strings
name = "Jack Robins"
phone = "0400056596"
address = "40 Patullos Road, Lara"

# create new line function
details = "\n"

# create full details using previous new line function included
details = name + details + address + details + phone

print(details)