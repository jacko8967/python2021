# Contact: jacko8967@gmail.com
# Date Written: 21.02.2021
# Version: 1.0

# initialise numeric and string variables
length = 57
width = 19
area = 0
line = "\n"

# calculation 
answer = length * width

# display answer
print(" Length = ",length, "metres", line, "Width = ", width, "metres", line, "Area = ", answer, "metres")