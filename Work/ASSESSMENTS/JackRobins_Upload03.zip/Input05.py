# Inpute05.py
# Programmer: Jack Robins
# Date: 4/3/2021

# assigns users input into integers
number1 = int(input("Enter a whole number: "))
number2 = int(input("Enter another whole number: "))

# multiplies users numbers to get the answer
answer = number1 * number2

# prints users output as single numbers
print(number1)
print(number2)

# prints blank line
print()

# prints answer to user
print("Your 2 numbers multiplied together are: {0}".format(answer))
