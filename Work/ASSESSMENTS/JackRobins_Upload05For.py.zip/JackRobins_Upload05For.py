sum = 0

for num in range(2, 21, 2):
    sum = sum + num
print ("Sum of even numbers 2 to 20 is: {0}".format(sum))