print ("Hello Jack \nRobins!")
print ("40 Patullos Road \nLara")
print ("Phone : \n0400056596")