names = {
    "Ben Dover" : "ben.dover@gmail.com",
    "John Smith" : "john.smith@gmail.com",
    "Fred Jones" : "fred.jones@gmail.com",
    "Bill Strong" : "bill.strong@gmail.com"
}

key = input("Enter a name: ")

print(names[key])