myInterests = {
    "interest 1" : "IT",
    "interest 2" : "Watching TV",
    "interest 3" : "Wanting free time",
    "interest 4" : "Talking with friends"
}

print()

print(myInterests)

print()

Key = input("Enter an interest number (in the format 'interest x'): ")

print(myInterests[Key])