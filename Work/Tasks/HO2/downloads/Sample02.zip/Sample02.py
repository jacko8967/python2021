# Author: Philip O'Neill
# Contact: poneill@gordontafe.edu.au
# Date: 07/02/2018
# Date Mod: 13/02/2018

vicCities = "Ballarat\nHamilton\nWodonga"
vicTowns = "Ballan\nCasterton\nEdenhope\nBalmoral"

print("TOWNS: " + "\n" + vicTowns)
print("CITIES: " + "\n" + vicCities)
