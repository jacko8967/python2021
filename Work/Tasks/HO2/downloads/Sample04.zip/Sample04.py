# Author: Phil O'Neill
# Contact: poneill@gordontafe.edu.au
# Date Written: 07/02/2018
# Date Modified: 13/02/2018
# Version: 1.1

# initialise numeric and string variables
num1 = 12
num2 = 8
answer = 0
message = ""

# calculation
answer = num1 + num2

# build and print output string
print(num1, "added to", num2, "equals", answer)




