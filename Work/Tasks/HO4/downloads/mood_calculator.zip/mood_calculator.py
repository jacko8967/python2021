#Mood computer
#Using the elif clause
import random
print("This program senses your emotions")
print("You are...")
mood = random.randint(1,3)
if mood == 1:
#happy
    print("happy")
elif mood == 2:
    print("neutral")
elif mood == 3:
    print("sad")
else:
    print("Oh dear, you must be in a very bad mood!")
    print("...today")
input("\n press enter key to exit")
