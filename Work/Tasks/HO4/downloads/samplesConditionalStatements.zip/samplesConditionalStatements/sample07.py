# Conditional statement
# Using if else
# Take note of the indenting.

age = 0

age = int(input("Enter your age:"))

if (age > 18):
    print("You are an adult")

else:
    print("You are a minor")
